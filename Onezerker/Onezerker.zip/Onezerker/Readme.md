## Changelog

### Onezerker v1.4
Updated for SDK versions 0.7.4-0.7.6.

### Onezerker v1.3
Small update to fix ladders removing your offhand weapon.

### Onezerker v1.2
Fixed a few issues with scrolling when you have less than 4 weapons equipped.

### Onezerker v1.1
Fixed that scrolling or using the cycle weapons button on a controller would give you two different weapons.
Fixed that switching weapons would reload your offhand. Autoloader will still reload it normally.

### Onezerker v1.0
Inital Release.
