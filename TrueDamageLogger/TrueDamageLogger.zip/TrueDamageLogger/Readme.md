## Changelog

### True Damage Logger v1.1
Updated for SDK versions 0.7.4-0.7.6.

### True Damage Logger v1.0
Inital Release.
