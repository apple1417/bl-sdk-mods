## Changelog

### True Damage Logger v1.3
Updated to use some of the new features from SDK version 0.7.8.    
Most notably, the enabled state is now saved over game launches.

### True Damage Logger v1.2
Improved hook to give more accurate values.

### True Damage Logger v1.1
Updated for SDK versions 0.7.4-0.7.6.

### True Damage Logger v1.0
Inital Release.
