## Changelog

### Scaling Adjuster v1.2
Updated for SDK versions 0.7.4-0.7.6.

### Scaling Adjuster v1.1
Fixed that saved custom scaling would be applied when you load the game, not when you enable the mod.

### Scaling Adjuster v1.0
Inital Release.
