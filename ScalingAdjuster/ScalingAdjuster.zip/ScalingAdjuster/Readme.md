## Changelog

### Scaling Adjuster v1.7
Added support for AoDK.

### Scaling Adjuster v1.6
Updated to use some of the new features from SDK version 0.7.8.    
Most notably, the enabled state is now saved over game launches.

### Scaling Adjuster v1.5
Fixed that saved custom scaling would be applied with 100x the effect when you just enabled the mod, without changing the value.

### Scaling Adjuster v1.4
Now opens a webpage listing requirements when you don't install them all.

### Scaling Adjuster v1.3
Updated to use OptionsWrapper - no functionality changes.

### Scaling Adjuster v1.2
Updated for SDK versions 0.7.4-0.7.6.

### Scaling Adjuster v1.1
Fixed that saved custom scaling would be applied when you load the game, not when you enable the mod.

### Scaling Adjuster v1.0
Inital Release.
