## Changelog

### Hide Undiscovered Missions v1.1
Updated for SDK versions 0.7.4-0.7.6.

### Hide Undiscovered Missions v1.0
Inital Release.
