## Changelog

### Side Mission Randomizer v1.2
Updated for SDK versions 0.7.4-0.7.6.

### Side Mission Randomizer v1.1
Fixed that object dependencies were not removed, potentially causing softlocks.    
This does not affect randomization

### Side Mission Randomizer v1.0
Inital release.

Ever felt it was too easy to unlock all your favourite side missions? This mod randomizes their progression order. Turns the lovely (mostly) linear progression graph into a spaghetti nightmare.

This mod will create other mods in the sdk mod menu for each seed you generate, only one of which can be active at a time. If you want to share a seed with friends, select the main mod, open the settings file, and copy paste it over into their settings file.

If you want to spoil yourself you can also generate a dump of the exact mission progression.
