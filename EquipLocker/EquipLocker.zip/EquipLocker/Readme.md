# Equip Locker

### Equip Locker v1.3
Added an option to allegiance to enable usable items - fixing that serveral items such as health vials could get restricted.
Removed the last fix for turrets, and instead expliclity excluded vehicles. This fixes that health vials would go into your inventory if they were restricted.

### Equip Locker v1.2
Fixed that it was possible for the mod to lock you out of using items that weren't in your inventory - usually when using turrets.

### Equip Locker v1.1
Updated to use some of the new features from SDK version 0.7.8:
- The enabled state is now saved over game launches.
- Each restriction set now stores it's options in a nested menu.
Also added the ability to disable entire restriction sets.

### Equip Locker v1.0
Inital Release.
