# Equip Locker

### Equip Locker v1.1
Updated to use some of the new features from SDK version 0.7.8:
- The enabled state is now saved over game launches.
- Each restriction set now stores it's options in a nested menu.
Also added the ability to disable entire restriction sets.

### Equip Locker v1.0
Inital Release.
