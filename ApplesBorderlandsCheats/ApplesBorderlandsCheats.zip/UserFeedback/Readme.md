## Changelog

### User Feedback v1.1
Updated for SDK versions 0.7.4-0.7.6.
Added `VersionMajor` and `VersionMinor` fields to the package.

### User Feedback v1.0
Inital Release.
