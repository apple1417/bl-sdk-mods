## Changelog

### No Ads v1.2
Also remove the small MoTD DLC ads (thanks to mopioid).

### No BL3 Ads v1.1
Updated for SDK versions 0.7.4-0.7.6.

### No BL3 Ads v1.0
Inital Release.
