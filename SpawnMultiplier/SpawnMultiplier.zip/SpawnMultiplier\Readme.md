## Changelog

### Spawn Multiplier v1.1
Fixed that changing the multiplier could occasionally round spawn counts down to 0.    
Fixed that disabling the mod would not revert spawn counts.

### Spawn Multiplier v1.0
Inital Release
