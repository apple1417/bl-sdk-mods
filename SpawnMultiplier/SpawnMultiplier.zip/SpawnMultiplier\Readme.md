## Changelog

### Spawn Multiplier v1.0
Inital Release
