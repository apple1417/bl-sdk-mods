## Changelog

### Options Wrapper v1.2
Add kill switch for upcoming sdk version that internalizes the changes in this mod.

### Options Wrapper v1.1
Added an entry in the Mods list, so that users their version and verify that it's loaded.

### Options Wrapper v1.0
Inital Release.
