## Changelog

### Options Wrapper v1.1
Added an entry in the Mods list, so that users their version and verify that it's loaded.

### Options Wrapper v1.0
Inital Release.
