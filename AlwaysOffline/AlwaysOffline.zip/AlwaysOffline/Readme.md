## Changelog

### Always Offline v1.1
Updated for SDK versions 0.7.4-0.7.6.

### Always Offline v1.0
Inital Release.
