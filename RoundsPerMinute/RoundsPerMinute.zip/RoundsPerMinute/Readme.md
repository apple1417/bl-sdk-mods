## Changelog

### Rounds Per Minute v1.1
Updated for SDK versions 0.7.4-0.7.6.

### Python Part Notifier v1.0
Inital Release.
