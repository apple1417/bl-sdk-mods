## Changelog

### Enemy Level Randomizer v1.1
Updated for SDK versions 0.7.4-0.7.6.

### Enemy Level Randomizer v1.0
Inital Release.
