## Changelog

### Enemy Level Randomizer v1.3
Updated to use some of the new features from SDK version 0.7.8.    
Most notably, the enabled state is now saved over game launches.

### Enemy Level Randomizer v1.2
Fixed issues with level clamping that could cause enemies to keep their original level if their randomized one went below 0 or above 255.
Removed the level 255 maximum.

### Enemy Level Randomizer v1.1
Updated for SDK versions 0.7.4-0.7.6.

### Enemy Level Randomizer v1.0
Inital Release.
