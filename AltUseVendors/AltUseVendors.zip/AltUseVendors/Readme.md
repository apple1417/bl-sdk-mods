## Changelog

### Alt Use Vendors v1.1
Made vendor prices only update while a player is near them, which should be more lag friendly.    
Also added an option to disable vendor price updating entirely - you won't see the prices anymore, but it should be even more lag friendly.

### Alt Use Vendors v1.0
Initial Release.
