## Changelog

### Item Level Uncapper v1.3
Updated to use some of the new features from SDK version 0.7.8.    
Most notably, the enabled state is now saved over game launches.    
Fixed that vehicle weapons were not being properly uncapped.

### Item Level Uncapper v1.2
Updated for SDK versions 0.7.4-0.7.6.    
Fixed some more cases of objects not being properly uncapped on map load.

### Item Level Uncapper v1.1
Fixed that some objects weren't uncapped properly on map load, most notably Krieg's Buzzaxe

### Item Level Uncapper v1.0
Inital Release.
