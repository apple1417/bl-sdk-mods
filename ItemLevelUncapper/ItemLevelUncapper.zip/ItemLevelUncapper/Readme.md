## Changelog

### Item Level Uncapper v1.2
Updated for SDK versions 0.7.4-0.7.6.
Fixed some more cases of objects not being properly uncapped on map load.

### Item Level Uncapper v1.1
Fixed that some objects weren't uncapped properly on map load, most notably Krieg's Buzzaxe

### Item Level Uncapper v1.0
Inital Release.
