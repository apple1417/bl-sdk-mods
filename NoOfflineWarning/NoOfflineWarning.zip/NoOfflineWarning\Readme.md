## Changelog

### No Offline Warning v1.1
Updated to use some of the new features from SDK version 0.7.8.

### No Offline Warning v1.0
Inital Release.
