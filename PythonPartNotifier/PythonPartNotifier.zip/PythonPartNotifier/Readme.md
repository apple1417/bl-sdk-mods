## Changelog

### Python Part Notifier v1.6
Adds curly single and double quotes to the unicode replacements, fixing a few cases it broke in Exodus.

### Python Part Notifier v1.5
Now provides a font size option, to make the parts text smaller to reduce the chance that information gets cut off.    
Fixed a case where the part headers would get coloured on certain items if gearbox forgot to add a closing tag somewhere.

### Python Part Notifier v1.4
Updated to use some of the new features from SDK version 0.7.8.    
Most notably, the enabled state is now saved over game launches.

### Python Part Notifier v1.3
Now opens a webpage listing requirements when you don't install them all.

### Python Part Notifier v1.2
Updated to use OptionsWrapper - no functionality changes.

### Python Part Notifier v1.1
Updated for SDK versions 0.7.4-0.7.6.
The glitch weapon accessories should all now properly have their effect displayed.

### Python Part Notifier v1.0
Inital Release.
