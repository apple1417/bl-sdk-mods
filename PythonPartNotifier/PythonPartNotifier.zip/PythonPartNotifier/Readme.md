## Changelog

### Python Part Notifier v1.1
Updated for SDK versions 0.7.4-0.7.6.
The glitch weapon accessories should all now properly have their effect displayed.

### Python Part Notifier v1.0
Inital Release.
