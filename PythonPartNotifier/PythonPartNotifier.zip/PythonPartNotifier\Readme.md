## Changelog

### Python Part Notifier v1.3
Now opens a webpage listing requirements when you don't install them all.

### Python Part Notifier v1.2
Updated to use OptionsWrapper - no functionality changes.

### Python Part Notifier v1.1
Updated for SDK versions 0.7.4-0.7.6.
The glitch weapon accessories should all now properly have their effect displayed.

### Python Part Notifier v1.0
Inital Release.
