## Changelog

### SDK Autorun v1.5
Updated to use some of the new features from SDK version 0.7.8.

### SDK Autorun v1.4
Now also opens a webpage warning you when requirements are outdated.

### SDK Autorun v1.3
Now opens a webpage listing requirements when you don't install them all.

### SDK Autorun v1.2
Fixed that autorunning tasks would be interupted if other SDK mods caused an exception.

### SDK Autorun v1.1
Fixed that the mod was making all other mods have a `[T] Edit Tasks` bind in their description.

### SDK Autorun v1.0
Inital Release.
