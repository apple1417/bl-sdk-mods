## Changelog

### SDK Autorun v1.1
Fixed that the mod was making all other mods have a `[T] Edit Tasks` bind in their description.

### SDK Autorun v1.0
Inital Release.
