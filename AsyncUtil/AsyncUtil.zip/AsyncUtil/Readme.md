## Changelog

### AsyncUtil v1.2
Updated to use some of the new features from SDK version 0.7.8.

### AsyncUtil v1.1
Added an entry in the Mods list, so that users their version and verify that it's loaded.

### AsyncUtil v1.0
Inital Release.
