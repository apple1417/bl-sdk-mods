# Chat Crasher
Crashes the game when using chat, either by typing manually or by execing a mod file containing a say command.

Also forces the game to never connect to SHiFT.

## Changelog

### Chat Crasher v1.1
Renamed to Chat Crasher.

### Always Offline v1.1
Updated for SDK versions 0.7.4-0.7.6.

### Always Offline v1.0
Inital Release.
