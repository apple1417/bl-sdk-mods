# Chat Crasher
Crashes the game when using chat, either by typing manually or by execing a mod file containing a say command.    
Also happens to force the game to never connect to SHiFT. :)

Intentionally not listed in the wiki because people can't read and then complain about the game crashing.

## Changelog

### Chat Crasher v1.2
Updated to use some of the new features from SDK version 0.7.8.

### Chat Crasher v1.1
Renamed to Chat Crasher.

### Always Offline v1.1
Updated for SDK versions 0.7.4-0.7.6.

### Always Offline v1.0
Inital Release.
